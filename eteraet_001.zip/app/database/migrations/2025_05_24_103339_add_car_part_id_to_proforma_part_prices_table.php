<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('proforma_part_prices', function (Blueprint $table) {
            // Add new columns to the existing table
            $table->decimal('unit_price', 10, 2)->nullable()->after('price');
            $table->decimal('part_total', 10, 2)->nullable()->after('unit_price');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('proforma_part_prices', function (Blueprint $table) {
            $table->dropColumn(['unit_price', 'part_total']);
        });
    }
};
